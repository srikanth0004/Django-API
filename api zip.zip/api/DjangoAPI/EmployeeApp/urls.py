from django.urls import path
from . import views


urlpatterns=[
    path('department',views.departmentApi),
    # path('product-create/', views.CreateProduct, name='product-create'),
    # path('',views.departmentApi),
    path('employee',views.employeeApi),

]